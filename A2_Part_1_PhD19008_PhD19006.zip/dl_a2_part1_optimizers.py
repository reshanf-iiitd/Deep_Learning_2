


import pandas as pd
import pandas as pdo
import plotly.express as px
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn import metrics
import pickle

import scipy
from tabulate import tabulate
import PIL 
import seaborn as sns
from sklearn.metrics import confusion_matrix
import numpy as np
import matplotlib.pyplot as plt
import os
import pickle
import scipy.io as sio

#drive/My Drive/Colab Notebooks/ML(PG)_assignment_1/dataset_1.mat')


def get_minibatch(X, y, minibatch_size = 64):
    minibatches = []

 # for the second question pass minibatch 64
    for i in range(0, X.shape[0], minibatch_size):
        X_mini = X[i:i + minibatch_size]
        y_mini = y[i:i + minibatch_size]

        minibatches.append((X_mini, y_mini))

    return minibatches


def momentum(model, X_train, y_train, minibatch_size = 64):
    velocity = {k: np.zeros_like(v) for k, v in model.items()}
    ### Setting the gamma value
    gamma = .9
    alpha = 1e-2

    minibatches = get_minibatch(X_train, y_train, minibatch_size)

    ############### No of n_iter =100 
    # n_iter is hyperpaprameter
    for iter in range(1, 151):
        idx = np.random.randint(0, len(minibatches))
        X_mini, y_mini = minibatches[idx]

        grad = get_minibatch_grad(model, X_mini, y_mini)

        for layer in grad:
            # adding the velcotiy to add momentum REST are same with SGD
            velocity[layer] = gamma * velocity[layer] + alpha * grad[layer]
            model[layer] += velocity[layer]

    return model


################################################  NESTROV #############################################################
def nesterov(model, X_train, y_train, minibatch_size = 64):
    velocity = {k: np.zeros_like(v) for k, v in model.items()}
    gamma = .9
    alpha = 1e-2

    minibatches = get_minibatch(X_train, y_train, minibatch_size)

    for iter in range(1, 151):
        idx = np.random.randint(0, len(minibatches))
        X_mini, y_mini = minibatches[idx]
        ############################# IT calculated the gradient at the approximated new position.
        model_ahead = {k: v + gamma * velocity[k] for k, v in model.items()}
        grad = get_minibatch_grad(model_ahead, X_mini, y_mini)

        for layer in grad:
            velocity[layer] = gamma * velocity[layer] + alpha * grad[layer]
            model[layer] += velocity[layer]

    return model



##################################################   ADAGRAD #####################################
def adagrad(model, X_train, y_train, minibatch_size = 64):
    cache = {k: np.zeros_like(v) for k, v in model.items()}
    alpha = 1e-2
    eps = 1e-8


    minibatches = get_minibatch(X_train, y_train, minibatch_size)

    for iter in range(1, 151):
        idx = np.random.randint(0, len(minibatches))
        X_mini, y_mini = minibatches[idx]

        grad = get_minibatch_grad(model, X_mini, y_mini)

        for k in grad:
            cache[k] += grad[k]**2
            model[k] += alpha * grad[k] / (np.sqrt(cache[k]) + eps)

    return model

####################################   RMSPOP OPTIMIZER ####################################
def rmsprop(model, X_train, y_train, minibatch_size=64):
    cache = {k: np.zeros_like(v) for k, v in model.items()}
    gamma = .9
    alpha = 1e-2
    eps = 1e-8

    minibatches = get_minibatch(X_train, y_train, minibatch_size)

    for iter in range(1, 151):
        idx = np.random.randint(0, len(minibatches))
        X_mini, y_mini = minibatches[idx]

        grad = get_minibatch_grad(model, X_mini, y_mini)

        for k in grad:
            cache[k] = gamma * cache[k] + (1 - gamma) * (grad[k]**2)
            model[k] += alpha * grad[k] / (np.sqrt(cache[k]) + eps)

    return model



def adam(model, X_train, y_train, minibatch_size = 64):
    M = {k: np.zeros_like(v) for k, v in model.items()}
    R = {k: np.zeros_like(v) for k, v in model.items()}
    beta1 = .9
    beta2 = .999
    eps = 1e-8
    alpha = 1e-2

    minibatches = get_minibatch(X_train, y_train, minibatch_size)

    for iter in range(1, 151):
        t = iter
        idx = np.random.randint(0, len(minibatches))
        X_mini, y_mini = minibatches[idx]

        grad = get_minibatch_grad(model, X_mini, y_mini)

        for k in grad:
            M[k] = beta1 * M[k] + (1. - beta1) * grad[k]
            R[k] = beta2 * R[k] + (1. - beta2) * grad[k]**2

            m_k_hat = M[k] / (1. - beta1**(t))
            r_k_hat = R[k] / (1. - beta2**(t))

            model[k] += alpha * m_k_hat / (np.sqrt(r_k_hat) + eps)

    return model


def make_network(n_hidden=150):
    model = dict(
        W1=np.random.randn(784, n_hidden),
        W2=np.random.randn(n_hidden, 10)
    )

    return model


def softmax(x):
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum()


def forward(x, model):
    # Input to hidden
    h = x @ model['W1']
    h[h < 0] = 0

    # Hidden to output
    prob = softmax(h @ model['W2'])

    return h, prob


def backward(model, xs, hs, errs):
    dW2 = hs.T @ errs

    dh = errs @ model['W2'].T
    dh[hs < 0] = 0
    dW1 = xs.T @ dh

    return dict(W1=dW1, W2=dW2)


def get_minibatch_grad(model, X_train, y_train):
    xs, hs, errs = [], [], []

    for x, cls_idx in zip(X_train, y_train):
        h, y_pred = forward(x, model)

        y_true = np.zeros(10)
        y_true[int(cls_idx)] = 1.
        err = y_true - y_pred

        xs.append(x)
        hs.append(h)
        errs.append(err)

    return backward(model, np.array(xs), np.array(hs), np.array(errs))




if __name__ == "__main__":

	f = open('train_set.pkl', 'rb')   # 'r' for reading; can be omitted
	mat = pickle.load(f)         # load file content as mydict
	f.close()

	f1 = open('val_set.pkl', 'rb')   # 'r' for reading; can be omitted
	mat1 = pickle.load(f1)         # load file content as mydict
	f1.close()

	X = mat['Image']
	X1=np.empty(shape=(10000,28,28),dtype='float')
	Y = mat['Labels']
	for x in range(len(X)):
	  X1[x] = np.asarray(X[x])


	X11 = mat1['Image']
	print(X11.shape)
	X111=np.empty(shape=(2000,28,28),dtype='float')
	Y11 = mat1['Labels']
	for x in range(len(X11)):
	  X111[x] = np.asarray(X11[x])


	##############################   DATA VISULIZATION ###########################
	fig, axes = plt.subplots(10,10, figsize=(10,10))
	for i,ax in enumerate(axes.flat):
	    ax.imshow(np.squeeze(X1[i]))
	##############################################################################
	X1 = X1.reshape(10000,784)
	X111 = X111.reshape(2000,784)
	X1.shape
	X111.shape

	X_train = X1
	y_train = Y
	y_test = Y11
	X_test = X111
	print(X_train.shape)
	print(X_test.shape)
	print(y_train.shape)
	print(y_test.shape)

	"""**Refrence and Start Running from below cell **

	REFRENCE : 
	https://github.com/fanghao6666/neural-networks-and-deep-learning/blob/master/py/Optimization%20methods.py

	https://github.com/oreilly-japan/deep-learning-from-scratch/blob/master/common/optimizer.py

	https://towardsdatascience.com/how-to-implement-an-adam-optimizer-from-scratch-76e7b217f1cc

	https://towardsdatascience.com/coding-neural-network-forward-propagation-and-backpropagtion-ccf8cf369f76


	https://github.com/addyg/Neural-Network-from-Scratch/blob/master/02%20SRC/NeuralNetwork.py

	https://arxiv.org/pdf/1412.6980


	    eps = 1e-8  # deal with zero in denominator
	    alpha = 1e-2
	    ieration = 100
	    mini_batches_size = 64
	    beta1 = .9
	    beta2 = .999
	    gamma = 0.9
	"""

	######################################3    RUN FROM THIS ###########################################
	######################################3    RUN FROM THIS ###########################################
	######################################3    RUN FROM THIS ###########################################

	##################################################################
	######################   MOMENTUM OPTIMIZER  #####################
	##################################################################


	model = make_network()
	model = momentum(model, X_train, y_train, 64)

	y_pred = np.zeros_like(y_test)
	filename1 = 'momentum.sav'
	pickle.dump(model, open(filename1, 'wb'))

	for i, x in enumerate(X_test):
	  _, prob = forward(x, model)
	  # print(prob)
	  y = np.argmax(prob)
	  # print(" -- ",y)
	  y_pred[i] = y

	print("Accuracy",np.mean(y_pred == y_test)*100)

	print("Confusion Matrix = \n",confusion_matrix(y_test, y_pred))

	##################################################################
	######################   NESROV   OPTIMIZER  #####################
	##################################################################

	model = make_network()
	model = nesterov(model, X_train, y_train, 64)

	y_pred = np.zeros_like(y_test)

	filename2 = 'nestrov.sav'
	pickle.dump(model, open(filename2, 'wb'))

	for i, x in enumerate(X_test):
	  _, prob = forward(x, model)
	  y = np.argmax(prob)
	  y_pred[i] = y

	# print(np.mean(y_pred == y_test))

	print("Accuracy",np.mean(y_pred == y_test)*100)

	print("Confusion Matrix = \n",confusion_matrix(y_test, y_pred))

	##################################################################
	######################   ADAGRAD  OPTIMIZER  #####################
	##################################################################

	model = make_network()
	model = adagrad(model, X_train, y_train, 64)

	y_pred = np.zeros_like(y_test)

	filename3 = 'adagrad.sav'
	pickle.dump(model, open(filename3, 'wb'))


	for i, x in enumerate(X_test):
	  _, prob = forward(x, model)
	  y = np.argmax(prob)
	  y_pred[i] = y

	# print(np.mean(y_pred == y_test))

	print("Accuracy",np.mean(y_pred == y_test)*100)

	print("Confusion Matrix = \n",confusion_matrix(y_test, y_pred))

	##################################################################
	######################   RMSPROP  OPTIMIZER  #####################
	##################################################################

	model = make_network()
	model = rmsprop(model, X_train, y_train, 64)
	filename4 = 'rmsprop.sav'
	pickle.dump(model, open(filename4, 'wb'))

	y_pred = np.zeros_like(y_test)

	for i, x in enumerate(X_test):
	  _, prob = forward(x, model)
	  y = np.argmax(prob)
	  y_pred[i] = y

	# print(np.mean(y_pred == y_test))
	print("Accuracy",np.mean(y_pred == y_test)*100)

	print("Confusion Matrix = \n",confusion_matrix(y_test, y_pred))

	##################################################################
	##########################   ADAM OPTIMIZER  #####################
	##################################################################

	model = make_network()
	model = adam(model, X_train, y_train, 64)

	filename5 = 'adam.sav'
	pickle.dump(model, open(filename5, 'wb'))

	y_pred = np.zeros_like(y_test)

	for i, x in enumerate(X_test):
	  _, prob = forward(x, model)
	  y = np.argmax(prob)
	  y_pred[i] = y

	# print(np.mean(y_pred == y_test))

	print("Accuracy",np.mean(y_pred == y_test)*100)

	print("Confusion Matrix = \n",confusion_matrix(y_test, y_pred))